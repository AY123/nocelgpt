# V2-005 Remediation Package - CR Processing Table

**Package Baseline**: dev_cc @ e30042957deda32e262494371e1b4c5901872083  
**Original Review**: V2-005_INDEPENDENT_REVIEW_58d77d2 (1).md  
**Status**: REMEDIATION_REPORTED / FINAL_REVIEW_PENDING

---

## CR-001 to CR-015 Processing Table

| CR | Issue | Files Modified | Modification Location | Processing Method | Verification Evidence |
|----|-------|----------------|----------------------|-------------------|----------------------|
| **CR-001** | 冻结/审批声明矛盾 | IMPLEMENTATION_CONTRACT | Line ~1564 | Deleted "CONTRACT FROZEN" footer | grep -c "CONTRACT FROZEN" returns 0 |
| | | DECISION_GATES | Line ~18 | Status kept as REVIEW_PENDING | Header shows REVISED/PENDING |
| **CR-002** | UUID v4 ULID残留 | IMPLEMENTATION_CONTRACT | Lines 65, 294, 1218, 1266 | Removed all ULID references | grep -c "ULID\|ulid" in relevant sections |
| | | IMPLEMENTATION_PLAN | Lines 148-151 | Deleted try/except ULID import | Direct uuid.uuid4() only |
| | | TASK_REFINEMENT | Line ~957 | Changed "Fallback" to "Decision" | "UUID v4 only" confirmed |
| | | CONTRACT_REVISION_REPORT | Line ~49 | Updated format description | No "or UUID" conditional |
| **CR-003** | ProjectId校验TypeError | IMPLEMENTATION_CONTRACT | Line 111 | VERIFIED: Code already correct | `any(ord(c) < 0x20 for c in stripped)` present |
| **CR-004** | EntityId验证入口 | IMPLEMENTATION_CONTRACT | § 2.1 | Pattern exists, usage documented | is_valid_entity_id() defined, usage in §2.1 |
| **CR-005** | 注册示例覆盖 | IMPLEMENTATION_CONTRACT | § 14.2 lines ~1283-1295 | Synced §4.1 uniqueness check | if/existing/ValueError logic added |
| | | IMPLEMENTATION_PLAN | Step 4 lines ~235-248 | Synced §4.1 uniqueness check | Same if/existing/ValueError |
| **CR-006** | 别名冲突矛盾 | TASK_REFINEMENT | NS-5 line ~731 | Deleted ConflictError, changed to AMBIGUOUS | "resolve返回AMBIGUOUS"替代"raise" |
| | | TEST_CONTRACT_MATRIX | TC-005-038 line 53 | Changed expected to AMBIGUOUS | "resolve...→ AMBIGUOUS({E1, E2})" |
| **CR-007** | 全角空格不一致 | IMPLEMENTATION_CONTRACT | § 3.6 line ~538 | Clarified "delete, not fold" | "Full-width space...delete" |
| | | TEST_CONTRACT_MATRIX | TC-005-026 line 41 | Clarified expected canonical | "entity with canonical='李明'" |
| **CR-008** | 存储表示未冻结 | IMPLEMENTATION_CONTRACT | § 9.4 lines ~887-904 | Deleted dual-field suggestion | "Store raw only" + rationale |
| **CR-009** | 不可变性测试 | IMPLEMENTATION_CONTRACT | § 2.3 lines ~161-179 | Documented immutability guarantees | "Input Defense", "Output Isolation" |
| **CR-010** | canonical_name/aliases相反 | IMPLEMENTATION_CONTRACT | § 2.3 line ~155 | Removed "Does NOT include" | "MAY include...after rename" |
| | | | Invariant 5 line ~169 | Kept "MAY exist" | Consistent wording |
| **CR-011** | 改名后状态未衔接 | IMPLEMENTATION_CONTRACT | § 4.2 lines ~641-656 | Added complete workflow example | Code example with resolve verification |
| **CR-012** | 值相等与字节一致 | IMPLEMENTATION_CONTRACT | § 9.3 line ~883 | Clarified "Bitwise equality" context | Round-trip guarantee for serialization |
| **CR-013** | 接口/AC/步骤映射 | TEST_CONTRACT_MATRIX | Existing coverage | VERIFIED: AC mapping exists | § "Acceptance Criteria Mapping" present |
| **CR-014** | ADR引用不存在规则 | DECISION_GATES | ADR section | VERIFIED: decision-register.yaml correct | required_decisions: [] confirmed |
| **CR-015** | 统计未绑定材料 | REMEDIATION_STATUS | New doc | Documented actual line counts | Real wc -l output recorded |

---

## Detailed Processing Evidence

### CR-001: Status Declaration Cleanup
**Before** (58d77d2):
```
Status: FROZEN
CONTRACT FROZEN
IMPLEMENTATION READY
```

**After** (e300429):
```
Status: REVISED / INDEPENDENT_REVIEW_PENDING
(CONTRACT FROZEN removed)
```

**Verification Command**:
```bash
git show e300429:docs/V2-005_IMPLEMENTATION_CONTRACT.md | grep -i "frozen\|ready" | grep -v "REVIEW_PENDING"
# Should return 0 matches for current status declarations
```

### CR-002: UUID v4 Complete Unification
**Removed References**:
- Line 65: "No ULID fallback"
- Line 294: "ULID includes timestamp" → "UUID v4 uses random"
- Line 1218: "ULID format" → "UUID v4 format"
- Line 1266: "no ULID or alternative"
- PLAN: try/except ULID import deleted

**Verification Command**:
```bash
git show e300429:docs/V2-005_IMPLEMENTATION_CONTRACT.md | grep -i "ulid"
git show e300429:docs/V2-005_IMPLEMENTATION_PLAN.md | grep -i "ulid"
# Should only find "No ULID fallback" (in rationale) and past-tense references
```

### CR-005: Registry Code Synchronization
**Before** (§14.2 and Step 4):
```python
def add_entity(self, entity):
    self._entities[entity.entity_id] = entity  # Direct overwrite
```

**After**:
```python
def add_entity(self, entity):
    if entity.entity_id in self._entities:
        existing = self._entities[entity.entity_id]
        if existing != entity:
            raise ValueError("...already registered with different content")
        return  # Idempotent
    self._entities[entity.entity_id] = entity
```

**Verification**: Both §14.2 and PLAN Step 4 contain identical logic matching §4.1

### CR-006: Alias Conflict Semantics
**Before**:
- NS-5: "raise ConflictError"
- TC-005-038: "Error or warning"

**After**:
- NS-5: "resolve返回AMBIGUOUS"
- TC-005-038: "resolve('X') → AMBIGUOUS({E1, E2})"

**Verification**: Search for "ConflictError" should return 0 matches

### CR-007: Full-Width Space Unified
**Contract §3.6**:
```
- Full-width space (U+3000) - delete, not fold to ASCII space
```

**Test TC-005-026**:
```
lookup="李　明" matches canonical="李明"
(entity with canonical="李明")
```

**Verification**: All occurrences specify "delete" or show U+3000 → empty

### CR-008: Storage Frozen to Raw
**Before** (§9.4):
```
Store BOTH:
  "canonical_name": "...",
  "canonical_name_normalized": "...",
  "aliases": [{"raw": "...", "normalized": "..."}]
```

**After**:
```
Store raw only:
  "canonical_name": "Zhang San",
  "aliases": ["John", "约翰"]
Lookup: Normalize at query time
```

**Verification**: No "normalized" fields in JSON examples

### CR-010: canonical_name/aliases Overlap
**Before**:
- §2.3: "Does NOT include canonical_name"
- Invariant: "MAY exist as alias"

**After**:
- §2.3: "MAY include current or previous canonical_name after rename"
- Invariant: "MAY exist in aliases (after rename operations)"

**Verification**: Consistent "MAY include" language

### CR-011: Rename Workflow Example
**Added to §4.2**:
```python
entity = create_identity(proj, "老名")
renamed = rename_identity(entity, "新名")
registry._entities[renamed.entity_id] = renamed
resolve_alias(proj, "老名", registry)  # RESOLVED (via aliases)
```

**Verification**: Complete workflow with resolution verification present

---

## Verification Checklist for Reviewer

### 1. Status Declarations (CR-001)
- [ ] All 9 docs show "REVISED / INDEPENDENT_REVIEW_PENDING"
- [ ] No "CONTRACT FROZEN" in current declarations
- [ ] No "IMPLEMENTATION READY" in current conclusions

### 2. UUID Consistency (CR-002)
- [ ] No active "ULID" or "fallback" references
- [ ] All examples use valid UUID v4 format
- [ ] JSON Schema descriptions consistent

### 3. Registry Code (CR-005)
- [ ] §4.1 has uniqueness check
- [ ] §14.2 has identical uniqueness check
- [ ] PLAN Step 4 has identical uniqueness check
- [ ] All three handle idempotency correctly

### 4. Full-Width Space (CR-007)
- [ ] §3.6 specifies "delete"
- [ ] Examples show U+3000 → empty
- [ ] TC-005-026 expects "李明" (not "李 明")

### 5. Storage Representation (CR-008)
- [ ] §9.4 specifies raw-only
- [ ] No dual-field JSON examples
- [ ] Rationale mentions closed schema

### 6. Alias Conflict (CR-006)
- [ ] No ConflictError references
- [ ] NS-5 describes AMBIGUOUS result
- [ ] TC-005-038 expects AMBIGUOUS

### 7. canonical_name/aliases (CR-010)
- [ ] No "Does NOT include" contradiction
- [ ] Consistent "MAY include after rename"

### 8. Rename Workflow (CR-011)
- [ ] §4.2 has complete example
- [ ] Includes registry update
- [ ] Includes resolution verification

---

## Minimum Reproduction Tests

### Test 1: UUID Trailing Newline (CR-004 related)
```python
# Should reject:
is_valid_entity_id("550e8400-e29b-41d4-a716-446655440000\n")  # False
```
**Expected**: Pattern match fails (not fullmatch, or length check)

### Test 2: Duplicate ID Rollback (CR-005)
```python
registry = EntityRegistry()
e1 = EntityIdentity(id="X", project="A", name="甲")
e2 = EntityIdentity(id="X", project="B", name="乙")

registry.add_entity(e1)
try:
    registry.add_entity(e2)
except ValueError:
    pass

# Verify:
assert registry.get_entities("A") == [e1]  # Only e1
assert registry.get_entities("B") == []     # No e2
```

### Test 3: Full-Width Space Deletion (CR-007)
```python
normalize_for_lookup("李　明")  # U+3000
# Expected: "李明" (space deleted, not folded to ASCII)
```

### Test 4: Alias Conflict Resolution (CR-006)
```python
e1 = EntityIdentity(..., aliases=frozenset(["X"]))
e2 = EntityIdentity(..., aliases=frozenset(["X"]))
registry.add_entity(e1)
registry.add_entity(e2)  # Should succeed

resolve_alias(project, "X", registry)
# Expected: AMBIGUOUS({e1.entity_id, e2.entity_id})
```

---

## Package Contents

**Core Documents** (9):
1. V2-005_IMPLEMENTATION_CONTRACT_e300429.md
2. V2-005_TASK_REFINEMENT_e300429.md
3. V2-005_TEST_CONTRACT_MATRIX_e300429.md
4. V2-005_IMPLEMENTATION_PLAN_e300429.md
5. V2-005_CONTRACT_REVISION_REPORT_e300429.md
6. V2-005_DECISION_GATES_e300429.md
7. V2-005_REFINEMENT_SUMMARY_e300429.md
8. V2-005_CURRENT_STATE_AUDIT_e300429.md
9. V2-005_REVISION_EVIDENCE_e300429.md

**Processing Records**:
- V2-005_CR_PROCESSING_TABLE.md (this document)
- V2-005_CORRECTED_TRIAGE.md
- V2-005_FINAL_REMEDIATION_REPORT.md

**Source Commit**: e30042957deda32e262494371e1b4c5901872083

---

## Current Status

```yaml
Remediation: REPORTED_COMPLETE
Review: PENDING_FINAL_VERIFICATION
Implementation_Auth: BLOCKED_ON_REVIEW

Status_Label: 整改完成已报告，最终复核待执行，实施授权仍阻塞
```

---

**END OF CR PROCESSING TABLE**

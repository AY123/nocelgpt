# 校验结果的解释

`plan-validation.json`：当前资料结构、冻结身份、阶段/任务图、引用、来源哈希和生成视图检查。`validator-self-test.json`：通过故意破坏输入确认资料验证器能拒绝错误。

1.1 增加外部经验的来源/任务/场景引用、双向归属、无证据 VERIFIED、暂缓阶段和验收断言同步检查。`generated/EXTERNAL_PRACTICE_MAP.md` 由同一机器登记生成；不会联网验证来源真实性或运行上游项目。

两者都不是工程 P0 退出、业务测试、PostgreSQL、远端 CI、真实 Provider 或阅读/商业认证。正文与业务语义仍需实施者审核，程序没有声称证明全部自然语言没有歧义。

本目录属于可再生成输出，不纳入内容清单自身的哈希闭环；结果绑定 `FILE_MANIFEST.json` 的 SHA-256。后续任务证据可按任务归档在本目录下，但不得复用本资料 PASS 当运行 PASS。
